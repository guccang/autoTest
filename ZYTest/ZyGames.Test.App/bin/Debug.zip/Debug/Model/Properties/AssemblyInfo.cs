
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Script.Model")]
[assembly: AssemblyProduct("Script.Model")]
[assembly: AssemblyCopyright("Copyright Scut")]
[assembly: ComVisible(false)]
[assembly: Guid("86982b0b-478e-4c08-ba2d-6d0c2dd217f4")]
[assembly: AssemblyVersion("1.0.0.1")]
