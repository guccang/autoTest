
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Script.Case")]
[assembly: AssemblyProduct("Script.Case")]
[assembly: AssemblyCopyright("Copyright Scut")]
[assembly: ComVisible(false)]
[assembly: Guid("c76bebb9-75bf-4d12-99da-1269ed954d16")]
[assembly: AssemblyVersion("1.0.0.2")]
